"use server";

import { revalidatePath } from "next/cache";
import { getCurrentDealerContext } from "@/lib/services/auth";
import { getDealerPreferences, upsertDealerPreferences } from "@/lib/services/preferences";
import type { MonitoringIntensity } from "@/types/domain";

function parseNumber(value: FormDataEntryValue | null, fallback: number): number {
  const parsed = Number(value);
  if (Number.isNaN(parsed)) return fallback;
  return parsed;
}

function parseMultiValue(value: FormDataEntryValue | null): string[] {
  if (!value) return [];
  return String(value)
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
}

function parseMonitoringIntensity(value: FormDataEntryValue | null, fallback: MonitoringIntensity): MonitoringIntensity {
  const normalized = String(value ?? "").trim().toLowerCase();
  if (normalized === "low" || normalized === "balanced" || normalized === "high") {
    return normalized;
  }
  return fallback;
}

export async function updatePreferencesAction(formData: FormData) {
  const context = await getCurrentDealerContext();
  const current = await getDealerPreferences(context.dealerId);

  const next = {
    ...current,
    dealerId: context.dealerId,
    preferredBrands: parseMultiValue(formData.get("preferredBrands")),
    preferredModels: parseMultiValue(formData.get("preferredModels")),
    minYear: parseNumber(formData.get("minYear"), current.minYear),
    maxMileage: parseNumber(formData.get("maxMileage"), current.maxMileage),
    maxPrice: parseNumber(formData.get("maxPrice"), current.maxPrice),
    minExpectedProfit: parseNumber(formData.get("minExpectedProfit"), current.minExpectedProfit),
    fuelTypes: parseMultiValue(formData.get("fuelTypes")) as typeof current.fuelTypes,
    transmissions: parseMultiValue(formData.get("transmissions")) as typeof current.transmissions,
    monitoringIntensity: parseMonitoringIntensity(formData.get("monitoringIntensity"), current.monitoringIntensity),
    selectedSourceGroups: parseMultiValue(formData.get("selectedSourceGroups")),
    updatedAt: new Date().toISOString()
  };

  await upsertDealerPreferences(next);
  revalidatePath("/settings");
  revalidatePath("/dashboard");
}
