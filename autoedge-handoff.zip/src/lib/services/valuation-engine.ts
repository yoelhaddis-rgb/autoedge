import type { Listing, Valuation } from "@/types/domain";
import { calculateProfit } from "@/lib/utils/deal";

export type ComparableInput = {
  listing: Listing;
  referenceValue: number;
  strictMatch: boolean;
  similarityScore: number;
};

export type ComputedValuation = {
  lowEstimate: number;
  medianEstimate: number;
  highEstimate: number;
  expectedCosts: number;
  expectedProfit: number;
  confidenceScore: number;
  dealScore: number;
  reasons: string[];
  risks: string[];
  selectedComparables: ComparableInput[];
};

export type ValuationEngine = {
  estimate(listing: Listing, candidates: ComparableInput[]): Promise<ComputedValuation>;
};

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

function percentile(values: number[], targetPercentile: number): number {
  if (values.length === 0) return 0;
  if (values.length === 1) return values[0];

  const index = (values.length - 1) * targetPercentile;
  const lower = Math.floor(index);
  const upper = Math.ceil(index);

  if (lower === upper) return values[lower];
  const ratio = index - lower;
  return Math.round(values[lower] + (values[upper] - values[lower]) * ratio);
}

function estimateExpectedCosts(listing: Listing): number {
  const currentYear = new Date().getFullYear();
  const ageYears = Math.max(0, currentYear - listing.year);
  const mileageFactor = Math.max(0, listing.mileage - 80000) / 10000;

  const fuelAdjustment =
    listing.fuel === "Diesel" ? 220 : listing.fuel === "Electric" ? 180 : listing.fuel === "Hybrid" ? 150 : 120;

  const transmissionAdjustment = listing.transmission === "Automatic" ? 120 : 80;

  const raw = 700 + ageYears * 140 + mileageFactor * 220 + fuelAdjustment + transmissionAdjustment;
  return clamp(Math.round(raw), 650, 6500);
}

function buildReasons(
  listing: Listing,
  medianEstimate: number,
  expectedProfit: number,
  confidenceScore: number,
  strictMatchCount: number,
  comparableCount: number
): string[] {
  const reasons: string[] = [];
  const spread = medianEstimate - listing.askingPrice;

  if (spread >= 1200) {
    reasons.push("asking price is materially below the comparable median");
  }

  if (expectedProfit >= 1500) {
    reasons.push("expected profit clears a strong margin threshold");
  }

  if (confidenceScore >= 75) {
    reasons.push("comparable coverage supports a confident valuation range");
  }

  if (listing.year >= new Date().getFullYear() - 6 && listing.mileage <= 120000) {
    reasons.push("year and mileage profile matches high-liquidity inventory");
  }

  if (strictMatchCount >= 4 && comparableCount >= 6) {
    reasons.push("multiple close matches were found on drivetrain and spec");
  }

  if (reasons.length === 0) {
    reasons.push("valuation built from available comparable inventory");
  }

  return reasons.slice(0, 4);
}

function buildRisks(listing: Listing, expectedProfit: number, comparableCount: number, spreadRatio: number): string[] {
  const risks: string[] = [];

  if (expectedProfit <= 800) {
    risks.push("profit headroom is thin after expected costs");
  }

  if (listing.mileage >= 150000) {
    risks.push("high mileage may reduce resale velocity");
  }

  if (listing.year <= new Date().getFullYear() - 10) {
    risks.push("older model year can increase pricing pressure");
  }

  if (comparableCount < 4) {
    risks.push("limited comparable coverage lowers confidence");
  }

  if (spreadRatio > 0.2) {
    risks.push("wide valuation spread indicates higher pricing uncertainty");
  }

  if (risks.length === 0) {
    risks.push("no major structural risks detected in current model");
  }

  return risks.slice(0, 4);
}

export class ComparableInventoryValuationEngine implements ValuationEngine {
  async estimate(listing: Listing, candidates: ComparableInput[]): Promise<ComputedValuation> {
    const selectedComparables = [...candidates]
      .sort((a, b) => a.similarityScore - b.similarityScore)
      .slice(0, 8);

    if (selectedComparables.length === 0) {
      const medianEstimate = Math.round(listing.askingPrice * 1.06);
      const lowEstimate = Math.round(medianEstimate * 0.94);
      const highEstimate = Math.round(medianEstimate * 1.08);
      const expectedCosts = estimateExpectedCosts(listing);
      const expectedProfit = calculateProfit(medianEstimate, listing.askingPrice, expectedCosts);

      return {
        lowEstimate,
        medianEstimate,
        highEstimate,
        expectedCosts,
        expectedProfit,
        confidenceScore: 28,
        dealScore: clamp(Math.round(40 + (expectedProfit / Math.max(1, listing.askingPrice)) * 80), 10, 65),
        reasons: ["fallback estimate used because no comparable inventory matched"],
        risks: ["very limited comparable coverage for this listing"],
        selectedComparables: []
      };
    }

    const comparableValues = selectedComparables
      .map((item) => item.referenceValue)
      .sort((a, b) => a - b);

    const lowEstimate = percentile(comparableValues, 0.25);
    const medianEstimate = percentile(comparableValues, 0.5);
    const highEstimate = percentile(comparableValues, 0.75);
    const expectedCosts = estimateExpectedCosts(listing);
    const expectedProfit = calculateProfit(medianEstimate, listing.askingPrice, expectedCosts);

    const strictMatchCount = selectedComparables.filter((item) => item.strictMatch).length;
    const comparableCount = selectedComparables.length;
    const spreadRatio = (highEstimate - lowEstimate) / Math.max(1, medianEstimate);

    const countScore = clamp(comparableCount * 9, 10, 45);
    const strictScore = clamp(strictMatchCount * 5, 0, 20);
    const spreadScore = clamp(36 - Math.round(spreadRatio * 110), 8, 36);
    const confidenceScore = clamp(countScore + strictScore + spreadScore, 20, 95);

    const profitRatio = expectedProfit / Math.max(1, listing.askingPrice);
    const marginScore = clamp(Math.round(50 + profitRatio * 140), 0, 100);
    const dealScore = clamp(
      Math.round(marginScore * 0.7 + confidenceScore * 0.3 + (expectedProfit < 0 ? -20 : 0)),
      0,
      100
    );

    return {
      lowEstimate,
      medianEstimate,
      highEstimate,
      expectedCosts,
      expectedProfit,
      confidenceScore,
      dealScore,
      reasons: buildReasons(
        listing,
        medianEstimate,
        expectedProfit,
        confidenceScore,
        strictMatchCount,
        comparableCount
      ),
      risks: buildRisks(listing, expectedProfit, comparableCount, spreadRatio),
      selectedComparables
    };
  }
}

export class SeedValuationEngine {
  async estimateFallback(listing: Listing): Promise<Valuation> {
    const medianEstimate = Math.round(listing.askingPrice * 1.1);
    const lowEstimate = Math.round(medianEstimate * 0.95);
    const highEstimate = Math.round(medianEstimate * 1.06);
    const expectedCosts = Math.round(listing.askingPrice * 0.06);

    return {
      id: `generated-${listing.id}`,
      listingId: listing.id,
      lowEstimate,
      medianEstimate,
      highEstimate,
      expectedCosts,
      expectedProfit: calculateProfit(medianEstimate, listing.askingPrice, expectedCosts),
      confidenceScore: 60,
      dealScore: 55,
      reasons: ["generated baseline valuation"],
      risks: ["valuation engine in fallback mode"],
      createdAt: new Date().toISOString()
    };
  }
}
