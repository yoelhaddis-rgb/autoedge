export function getDealScoreLabel(score: number): "High Potential" | "Interesting" | "Moderate" | "Risk" {
  if (score >= 80) return "High Potential";
  if (score >= 60) return "Interesting";
  if (score >= 40) return "Moderate";
  return "Risk";
}

export function getDealScoreClass(score: number): string {
  if (score >= 80) return "bg-success/20 text-success border-success/40";
  if (score >= 60) return "bg-accent/20 text-accent border-accent/40";
  if (score >= 40) return "bg-warning/20 text-warning border-warning/40";
  return "bg-danger/20 text-danger border-danger/40";
}

export function calculateProfit(medianEstimate: number, askingPrice: number, expectedCosts: number): number {
  return Math.round(medianEstimate - askingPrice - expectedCosts);
}
