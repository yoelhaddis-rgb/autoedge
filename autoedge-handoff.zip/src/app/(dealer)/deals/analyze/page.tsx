import Link from "next/link";
import { ArrowLeft, CircleGauge, Database, ScanSearch } from "lucide-react";
import { analyzeVehicleAction } from "@/actions/analyze";
import { Button, buttonClassName } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { isSupabaseConfigured } from "@/lib/supabase/env";

type AnalyzeVehiclePageProps = {
  searchParams: Promise<{ error?: string }>;
};

export default async function AnalyzeVehiclePage({ searchParams }: AnalyzeVehiclePageProps) {
  const params = await searchParams;
  const supabaseReady = isSupabaseConfigured();

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm text-foreground/60">Manual valuation workflow</p>
          <h1 className="font-heading text-3xl text-foreground">Analyze Vehicle</h1>
          <p className="mt-1 text-sm text-foreground/60">
            Enter a vehicle manually and AutoEdge will calculate valuation, profit potential, and comparable coverage.
          </p>
        </div>
        <Link href="/deals" className={buttonClassName({ variant: "secondary", className: "gap-2" })}>
          <ArrowLeft className="h-4 w-4" />
          Back to deals
        </Link>
      </div>

      {params.error && (
        <Card className="border-danger/40 bg-danger/10">
          <p className="text-sm text-danger">{params.error}</p>
        </Card>
      )}

      {!supabaseReady && (
        <Card className="border-warning/40 bg-warning/10">
          <p className="text-sm text-warning">
            Supabase is nog niet geconfigureerd. Vul `NEXT_PUBLIC_SUPABASE_URL` en
            `NEXT_PUBLIC_SUPABASE_ANON_KEY` in `.env.local` en herstart `npm run dev`.
          </p>
        </Card>
      )}

      <section className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
        <Card>
          <form action={analyzeVehicleAction} className="grid gap-4 md:grid-cols-2">
            <div className="space-y-1">
              <label htmlFor="brand" className="text-sm text-foreground/70">
                Brand
              </label>
              <Input id="brand" name="brand" required placeholder="BMW" />
            </div>

            <div className="space-y-1">
              <label htmlFor="model" className="text-sm text-foreground/70">
                Model
              </label>
              <Input id="model" name="model" required placeholder="320d Touring" />
            </div>

            <div className="space-y-1 md:col-span-2">
              <label htmlFor="variant" className="text-sm text-foreground/70">
                Variant
              </label>
              <Input id="variant" name="variant" placeholder="M Sport" />
            </div>

            <div className="space-y-1">
              <label htmlFor="year" className="text-sm text-foreground/70">
                Year
              </label>
              <Input id="year" name="year" type="number" min={1995} max={2030} required placeholder="2019" />
            </div>

            <div className="space-y-1">
              <label htmlFor="mileage" className="text-sm text-foreground/70">
                Mileage (km)
              </label>
              <Input id="mileage" name="mileage" type="number" min={0} required placeholder="124000" />
            </div>

            <div className="space-y-1">
              <label htmlFor="askingPrice" className="text-sm text-foreground/70">
                Asking price (EUR)
              </label>
              <Input id="askingPrice" name="askingPrice" type="number" min={500} required placeholder="18950" />
            </div>

            <div className="space-y-1">
              <label htmlFor="location" className="text-sm text-foreground/70">
                Location
              </label>
              <Input id="location" name="location" required placeholder="Rotterdam" />
            </div>

            <div className="space-y-1">
              <label htmlFor="fuel" className="text-sm text-foreground/70">
                Fuel
              </label>
              <Select id="fuel" name="fuel" defaultValue="Diesel">
                <option value="Diesel">Diesel</option>
                <option value="Petrol">Petrol</option>
                <option value="Hybrid">Hybrid</option>
                <option value="Electric">Electric</option>
              </Select>
            </div>

            <div className="space-y-1">
              <label htmlFor="transmission" className="text-sm text-foreground/70">
                Transmission
              </label>
              <Select id="transmission" name="transmission" defaultValue="Automatic">
                <option value="Automatic">Automatic</option>
                <option value="Manual">Manual</option>
              </Select>
            </div>

            <div className="space-y-1 md:col-span-2">
              <label htmlFor="sourceUrl" className="text-sm text-foreground/70">
                Source URL (optional)
              </label>
              <Input id="sourceUrl" name="sourceUrl" type="url" placeholder="https://dealer-site.example/listing/123" />
            </div>

            <div className="space-y-1 md:col-span-2">
              <label htmlFor="notes" className="text-sm text-foreground/70">
                Notes (optional)
              </label>
              <Textarea id="notes" name="notes" rows={4} placeholder="Condition notes, expected repairs, contact context..." />
            </div>

            <div className="md:col-span-2 flex items-center justify-between rounded-xl border border-white/10 bg-white/[0.03] p-3 text-sm text-foreground/65">
              <p>The analysis will be saved to Supabase and added to your valuation opportunities feed.</p>
              <Button type="submit" className="gap-2" disabled={!supabaseReady}>
                <CircleGauge className="h-4 w-4" />
                Analyze and save
              </Button>
            </div>
          </form>
        </Card>

        <Card className="space-y-4">
          <div>
            <p className="font-heading text-xl text-foreground">What happens on submit</p>
            <p className="mt-1 text-sm text-foreground/60">AutoEdge runs a full valuation flow against stored inventory.</p>
          </div>

          <div className="rounded-xl border border-white/10 bg-white/[0.03] p-4">
            <p className="mb-2 inline-flex items-center gap-2 text-sm text-foreground">
              <Database className="h-4 w-4 text-accent" />
              Supabase write flow
            </p>
            <p className="text-sm text-foreground/65">
              The listing is saved first, then valuation/comparables are generated and stored in `valuations` and
              `comparables`.
            </p>
          </div>

          <div className="rounded-xl border border-white/10 bg-white/[0.03] p-4">
            <p className="mb-2 inline-flex items-center gap-2 text-sm text-foreground">
              <ScanSearch className="h-4 w-4 text-accent" />
              Comparable matching
            </p>
            <p className="text-sm text-foreground/65">
              Comparables are selected from existing inventory by brand/model, year, mileage, fuel and transmission,
              with a relaxed fallback match when coverage is low.
            </p>
          </div>
        </Card>
      </section>
    </div>
  );
}
