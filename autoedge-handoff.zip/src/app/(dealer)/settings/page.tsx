import { updatePreferencesAction } from "@/actions/settings";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { getCurrentDealerContext } from "@/lib/services/auth";
import { getDealerPreferences } from "@/lib/services/preferences";

export default async function SettingsPage() {
  const context = await getCurrentDealerContext();
  const preferences = await getDealerPreferences(context.dealerId);

  return (
    <div className="space-y-6">
      <div>
        <p className="text-sm text-foreground/60">Dealer profile</p>
        <h1 className="font-heading text-3xl text-foreground">Preferences</h1>
        <p className="mt-1 text-sm text-foreground/60">Tune filters so AutoEdge prioritizes the opportunities you actually buy.</p>
      </div>

      <Card>
        <form action={updatePreferencesAction} className="grid gap-4 md:grid-cols-2">
          <div className="space-y-1 md:col-span-2">
            <label htmlFor="preferredBrands" className="text-sm text-foreground/70">
              Preferred brands (comma separated)
            </label>
            <Input
              id="preferredBrands"
              name="preferredBrands"
              defaultValue={preferences.preferredBrands.join(", ")}
              placeholder="BMW, Audi, Volkswagen"
            />
          </div>

          <div className="space-y-1 md:col-span-2">
            <label htmlFor="preferredModels" className="text-sm text-foreground/70">
              Preferred models (comma separated)
            </label>
            <Input
              id="preferredModels"
              name="preferredModels"
              defaultValue={preferences.preferredModels.join(", ")}
              placeholder="Golf, A4 Avant, 320d Touring"
            />
          </div>

          <div className="space-y-1">
            <label htmlFor="minYear" className="text-sm text-foreground/70">
              Minimum year
            </label>
            <Input id="minYear" name="minYear" type="number" defaultValue={preferences.minYear} />
          </div>

          <div className="space-y-1">
            <label htmlFor="maxMileage" className="text-sm text-foreground/70">
              Maximum mileage (km)
            </label>
            <Input id="maxMileage" name="maxMileage" type="number" defaultValue={preferences.maxMileage} />
          </div>

          <div className="space-y-1">
            <label htmlFor="maxPrice" className="text-sm text-foreground/70">
              Maximum asking price (EUR)
            </label>
            <Input id="maxPrice" name="maxPrice" type="number" defaultValue={preferences.maxPrice} />
          </div>

          <div className="space-y-1">
            <label htmlFor="minExpectedProfit" className="text-sm text-foreground/70">
              Minimum expected profit (EUR)
            </label>
            <Input
              id="minExpectedProfit"
              name="minExpectedProfit"
              type="number"
              defaultValue={preferences.minExpectedProfit}
            />
          </div>

          <div className="space-y-1">
            <label htmlFor="fuelTypes" className="text-sm text-foreground/70">
              Fuel types (comma separated)
            </label>
            <Input
              id="fuelTypes"
              name="fuelTypes"
              defaultValue={preferences.fuelTypes.join(", ")}
              placeholder="Petrol, Diesel, Hybrid"
            />
          </div>

          <div className="space-y-1">
            <label htmlFor="transmissions" className="text-sm text-foreground/70">
              Transmissions (comma separated)
            </label>
            <Input
              id="transmissions"
              name="transmissions"
              defaultValue={preferences.transmissions.join(", ")}
              placeholder="Automatic, Manual"
            />
          </div>

          <div className="space-y-1">
            <label htmlFor="monitoringIntensity" className="text-sm text-foreground/70">
              Monitoring intensity
            </label>
            <Select id="monitoringIntensity" name="monitoringIntensity" defaultValue={preferences.monitoringIntensity}>
              <option value="low">Low (cost-efficient)</option>
              <option value="balanced">Balanced</option>
              <option value="high">High (more frequent checks)</option>
            </Select>
          </div>

          <div className="space-y-1">
            <label htmlFor="selectedSourceGroups" className="text-sm text-foreground/70">
              Selected dealer source groups (comma separated)
            </label>
            <Input
              id="selectedSourceGroups"
              name="selectedSourceGroups"
              defaultValue={preferences.selectedSourceGroups.join(", ")}
              placeholder="DealerStock NL, PremiumLease Exchange, RegionalAutoHub"
            />
          </div>

          <div className="md:col-span-2 flex items-center justify-between rounded-xl border border-white/10 bg-white/[0.03] p-3 text-sm text-foreground/65">
            <p>
              Monitoring intensity and source groups are UI-first controls for the upcoming selective monitoring engine.
            </p>
            <Button type="submit">Save preferences</Button>
          </div>
        </form>
      </Card>
    </div>
  );
}
