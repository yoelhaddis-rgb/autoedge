import { updateDealStatusAction } from "@/actions/deals";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

type DealStatusActionsProps = {
  listingId: string;
  note: string;
};

const actions = [
  { label: "Save deal", value: "saved" },
  { label: "Mark ignored", value: "ignored" },
  { label: "Mark contacted", value: "contacted" },
  { label: "Mark bought", value: "bought" }
] as const;

export function DealStatusActions({ listingId, note }: DealStatusActionsProps) {
  return (
    <div className="space-y-3">
      <form action={updateDealStatusAction} className="space-y-3">
        <input type="hidden" name="listingId" value={listingId} />
        <input type="hidden" name="status" value="saved" />
        <Textarea name="note" defaultValue={note} rows={3} placeholder="Internal note for your team" />
        <Button type="submit" fullWidth>
          Save with note
        </Button>
      </form>

      <div className="grid gap-2 sm:grid-cols-3">
        {actions.map((action) => (
          <form key={action.value} action={updateDealStatusAction}>
            <input type="hidden" name="listingId" value={listingId} />
            <input type="hidden" name="status" value={action.value} />
            <input type="hidden" name="note" value={note} />
            <Button type="submit" variant="secondary" fullWidth className="text-xs">
              {action.label}
            </Button>
          </form>
        ))}
      </div>
    </div>
  );
}
